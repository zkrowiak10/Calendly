


let outlookBase = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize";
let redirect = chrome.identity.getRedirectURL()
let params=
  `client_id=d25c3df7-f3bc-48f3-ba05-b395304067e7 redirect_uri=${redirect} response_type=code scope=openid Calendars.Read`

console.log(params);
let auth = encodeURI(outlookBase + JSON.stringify(params));
console.log(auth)
let requestURL = {'url': auth, 'interactive':true}
chrome.identity.launchWebAuthFlow(requestURL,function(response){
    console.log(response)
})












/*base = 'https://wordstream.my.salesforce.com/search/SearchResults?searchType=2&str=';
search = 'josh@brookslawgroup.com';
let target = encodeURI(base+search);

fetch(target, {credentials: "include", mode: 'cors'}).then(function(response) {
    console.log("Response:");
    console.log(response)
    return response.text()})
    .then(function(text){
        //console.log(text)
        let parser = new DOMParser();
        doc = parser.parseFromString(text, "text/html");
        let hrf = doc.getElementById('Account_body').getElementsByTagName('table')[0].rows[1].cells[1].getElementsByTagName('a')[0].getAttribute('href');
        console.log(hrf)
        /*fetch(hrf.getAttribute('href'), {credentials: "include", mode: 'cors'})
            .then(response=> {return response.text})
            .then(page=>{
                let html = parser.parseFromString(page,"text/html")
                html.getElementById("0010y00001ZAdI4_00N80000004l7nV_body")
                .getElementsByClassName("list")[0]
                .rows[1]
                .cells[1]
                .innerText
            
            })
    
        
            
        
    })*/
    
    
//helper functions

/*function getDoc(url){
    fetch(url,{credentials: "include", mode: 'cors'}).then(function(response) {
        return response.text()})
}*/